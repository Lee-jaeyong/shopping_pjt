-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 19-10-07 19:30 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `shopping`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `s_category`
--

CREATE TABLE IF NOT EXISTS `s_category` (
  `c_idx` int(11) NOT NULL,
  `c_i_idx` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`c_i_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=136 ;

--
-- 테이블의 덤프 데이터 `s_category`
--

INSERT INTO `s_category` (`c_idx`, `c_i_idx`) VALUES
(1, 1),
(1, 3),
(1, 5),
(1, 16),
(1, 15),
(1, 14),
(1, 13),
(1, 12),
(1, 11),
(1, 10),
(1, 9),
(1, 8),
(1, 7),
(1, 134),
(1, 126),
(1, 135);

-- --------------------------------------------------------

--
-- 테이블 구조 `s_categoryname`
--

CREATE TABLE IF NOT EXISTS `s_categoryname` (
  `cn_idx` int(11) NOT NULL AUTO_INCREMENT,
  `c_categoryName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cn_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- 테이블의 덤프 데이터 `s_categoryname`
--

INSERT INTO `s_categoryname` (`cn_idx`, `c_categoryName`) VALUES
(1, '상의'),
(7, '스커트'),
(3, '신발'),
(4, '가방'),
(5, '아우터'),
(6, '셔츠/블라우스'),
(8, '원피스'),
(9, '쥬얼리'),
(10, '악세사리'),
(11, 'ㄹㄴㅇ');

-- --------------------------------------------------------

--
-- 테이블 구조 `s_item`
--

CREATE TABLE IF NOT EXISTS `s_item` (
  `i_idx` int(11) NOT NULL AUTO_INCREMENT,
  `i_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `i_price` int(11) NOT NULL,
  `i_detailimg` text COLLATE utf8_unicode_ci NOT NULL,
  `i_option_id` int(11) NOT NULL,
  `i_info` text COLLATE utf8_unicode_ci NOT NULL,
  `i_hit` int(11) NOT NULL DEFAULT '0',
  `i_date` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`i_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=136 ;

--
-- 테이블의 덤프 데이터 `s_item`
--

INSERT INTO `s_item` (`i_idx`, `i_name`, `i_price`, `i_detailimg`, `i_option_id`, `i_info`, `i_hit`, `i_date`) VALUES
(1, '램스울V가디건', 143100, '', 2, '', 0, '2019-09-27 17:45:36'),
(3, '탄탄레글런루즈CD', 25000, '', 0, '', 0, '2019-09-27 17:45:36'),
(5, '여리브이CD&스커트set', 26000, '', 0, '', 0, '2019-09-27 17:45:36'),
(7, '도톰코지Y가디건', 22800, '', 0, '', 0, '2019-09-27 17:45:36'),
(8, '모카루즈가디건', 18900, '', 0, '', 0, '2019-09-27 17:45:36'),
(9, '박시쥬리가디건', 18000, '', 0, '', 0, '2019-09-27 17:45:36'),
(10, '알파카V울가디건', 29000, '', 0, '', 0, '2019-09-27 17:45:36'),
(11, '캐시V넥가디건', 19900, '', 0, '', 0, '2019-09-27 17:45:36'),
(12, '무드골지가디건&스커트set', 28000, '', 0, '', 0, '2019-09-27 17:45:36'),
(13, '탄탄Y니트가디건', 19900, '', 0, '', 0, '2019-09-27 17:45:36'),
(14, '물결단크롭CD', 19900, '', 0, '', 0, '2019-09-27 17:45:36'),
(15, '캐시Y포켓가디건', 19900, '', 0, '', 0, '2019-09-27 17:45:36'),
(16, '탄탄심쿵가디건', 18900, '', 0, '', 0, '2019-09-27 17:45:36'),
(134, '럭스셔링블랑T', 12000, 'front/images/detailImg/190930-hr-3_02.jpg', 0, '가디건', 0, '2019-10-07 00:00:34'),
(135, 'ㄹㅇㄴㄹㅇㄴ', 32, 'front/images/detailImg/KakaoTalk_20190924_112430401.png', 0, 'ㄹㅇㄴ', 0, '2019-10-07 18:29:31');

-- --------------------------------------------------------

--
-- 테이블 구조 `s_mainimg`
--

CREATE TABLE IF NOT EXISTS `s_mainimg` (
  `img_idx` int(11) NOT NULL AUTO_INCREMENT,
  `img_path` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`img_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=136 ;

--
-- 테이블의 덤프 데이터 `s_mainimg`
--

INSERT INTO `s_mainimg` (`img_idx`, `img_path`) VALUES
(1, 'front/images/mainImg/1.jpeg'),
(3, 'front/images/mainImg/3.jpeg'),
(5, 'front/images/mainImg/5.jpeg'),
(7, 'front/images/mainImg/7.jpeg'),
(8, 'front/images/mainImg/8.jpeg'),
(9, 'front/images/mainImg/9.jpeg'),
(10, 'front/images/mainImg/10.jpeg'),
(11, 'front/images/mainImg/11.jpeg'),
(12, 'front/images/mainImg/12.jpeg'),
(13, 'front/images/mainImg/13.jpeg'),
(14, 'front/images/mainImg/14.jpeg'),
(15, 'front/images/mainImg/15.jpeg'),
(16, 'front/images/mainImg/16.jpeg'),
(134, 'front/images/mainImg/00196915-06.jpeg'),
(135, 'front/images/mainImg/KakaoTalk_20190924_112430401.png');

-- --------------------------------------------------------

--
-- 테이블 구조 `s_option`
--

CREATE TABLE IF NOT EXISTS `s_option` (
  `op_sc_idx` int(11) NOT NULL,
  `op_info_color` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `op_info_size` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 테이블의 덤프 데이터 `s_option`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `s_order`
--

CREATE TABLE IF NOT EXISTS `s_order` (
  `o_idx` int(11) NOT NULL AUTO_INCREMENT,
  `o_u_idx` int(11) NOT NULL,
  `o_i_idx` int(11) NOT NULL,
  `o_i_price` int(11) NOT NULL,
  `o_count` int(11) NOT NULL,
  `o_ordername` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `o_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `o_option` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `o_date` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`o_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 테이블의 덤프 데이터 `s_order`
--

INSERT INTO `s_order` (`o_idx`, `o_u_idx`, `o_i_idx`, `o_i_price`, `o_count`, `o_ordername`, `o_address`, `o_option`, `o_date`) VALUES
(1, 1, 1, 123123, 1, 'ewq', 'eqw', 'eqw', 'eqw');

-- --------------------------------------------------------

--
-- 테이블 구조 `s_small_category`
--

CREATE TABLE IF NOT EXISTS `s_small_category` (
  `cs_c_idx` int(11) NOT NULL,
  `cs_idx` int(11) NOT NULL,
  `cs_i_idx` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`cs_i_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=136 ;

--
-- 테이블의 덤프 데이터 `s_small_category`
--

INSERT INTO `s_small_category` (`cs_c_idx`, `cs_idx`, `cs_i_idx`) VALUES
(1, 1, 1),
(1, 1, 3),
(1, 1, 5),
(1, 1, 7),
(1, 1, 8),
(1, 1, 9),
(1, 1, 10),
(1, 1, 11),
(1, 1, 12),
(1, 1, 13),
(1, 1, 14),
(1, 1, 15),
(1, 1, 16),
(1, 1, 134),
(1, 3, 135);

-- --------------------------------------------------------

--
-- 테이블 구조 `s_small_categoryname`
--

CREATE TABLE IF NOT EXISTS `s_small_categoryname` (
  `c_idx` int(11) NOT NULL,
  `csn_idx` int(11) NOT NULL AUTO_INCREMENT,
  `cs_categoryName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`csn_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- 테이블의 덤프 데이터 `s_small_categoryname`
--

INSERT INTO `s_small_categoryname` (`c_idx`, `csn_idx`, `cs_categoryName`) VALUES
(1, 1, '가디건'),
(11, 2, 'ㄴㄴ'),
(1, 3, '셔츠');

-- --------------------------------------------------------

--
-- 테이블 구조 `s_stock`
--

CREATE TABLE IF NOT EXISTS `s_stock` (
  `st_i_idx` int(11) NOT NULL,
  `st_i_stock` int(11) NOT NULL,
  `st_sc_idx` int(11) NOT NULL,
  `st_op_idx` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 테이블의 덤프 데이터 `s_stock`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `s_user`
--

CREATE TABLE IF NOT EXISTS `s_user` (
  `u_idx` int(11) NOT NULL AUTO_INCREMENT,
  `u_identy` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_password` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `u_phone1` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `u_phone2` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `u_phone3` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `u_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_birth` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `u_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`u_idx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

--
-- 테이블의 덤프 데이터 `s_user`
--

INSERT INTO `s_user` (`u_idx`, `u_identy`, `u_password`, `u_email`, `u_phone1`, `u_phone2`, `u_phone3`, `u_name`, `u_birth`, `u_address`, `u_date`) VALUES
(1, 'admin', 'admin', '', '', '', '', '관리자', NULL, '', '2019-10-01'),
(2, 'admin2', 'admin2', '', '010', '1111', '2222', '관리자2', '0000000', '0000000', '2019-10-02'),
(35, NULL, NULL, 'wodyd202@naver.com', '', '', '', '이재용', NULL, '', NULL),
(36, NULL, NULL, '', '', '', '', '5', NULL, '', NULL),
(37, NULL, NULL, '', '', '', '', '4', NULL, '', NULL),
(38, NULL, NULL, '', '', '', '', '3', NULL, '', NULL),
(39, NULL, NULL, '', '', '', '', '2', NULL, '', NULL),
(40, NULL, NULL, '', '', '', '', '1', NULL, '', NULL);
